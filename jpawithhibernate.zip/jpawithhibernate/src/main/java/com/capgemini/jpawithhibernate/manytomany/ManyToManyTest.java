package com.capgemini.jpawithhibernate.manytomany;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ManyToManyTest {

	public static void main(String[] args) {


		Course c = new Course();
		c.setCid(101);
		c.setCname("Java");

		Course c1 = new Course();
		c1.setCid(102);
		c1.setCname("JPA with Hibernate");

		ArrayList<Course> al = new ArrayList<Course>();
		al.add(c);
		al.add(c1);

		Student s= new Student();
		s.setSid(1);
		s.setName("Tom");
		s.setCourse(al);
		
		Student s1 = new Student();
		s1.setSid(2);
		s1.setName("Jerry");
		s1.setCourse(al);


		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction t=null;

		try {

			emf=Persistence.createEntityManagerFactory("Test");
			em=emf.createEntityManager();
			t = em.getTransaction();
			t.begin();
			//em.persist(s1);
			//em.persist(s);
			//em.persist(c);
			//em.persist(c1);
			Course c3 = em.find(Course.class, 102);
			System.out.println("Id is :"+c3.getStudent().get(1).getSid());
			System.out.println("Name is :"+c3.getStudent().get(1).getName());
			System.out.println("0---------------------------------------------------");
			System.out.println("Id is :"+c3.getStudent().get(0).getSid());
			System.out.println("Name is :"+c3.getStudent().get(0).getName());


			System.out.println("Record Saved");
			t.commit();


		} catch (Exception e) {
			e.printStackTrace();
			t.rollback();

		}

		em.close();
	}

}
