package com.capgemini.jpawithhibernate.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetomany.Pencil;
import com.capgemini.jpawithhibernate.onetomany.PencilBox;

public class OneToManyTest {

	public static void main(String[] args) {

		PencilBox pencilBox = new PencilBox();
		pencilBox.setBoxid(30002);
		pencilBox.setName("Cambline");

		Pencil pencil = new Pencil();
		pencil.setPid(30);
		pencil.setColor("Blue");

		Pencil pencil1 = new Pencil();
		pencil1.setPid(45);
		pencil1.setColor("BLack");

		pencil1.setPencilBox(pencilBox);
		pencil.setPencilBox(pencilBox);

		EntityTransaction transaction = null;
		EntityManager entityManager =null;
		EntityManagerFactory entityManagerFactory = null;

		try 
		{
			entityManagerFactory = Persistence.createEntityManagerFactory("Test");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(pencil);
			entityManager.persist(pencil1);


			System.out.println(" Record saved");
			transaction.commit();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			transaction.rollback();

		}

		entityManager.close();

	}
}
