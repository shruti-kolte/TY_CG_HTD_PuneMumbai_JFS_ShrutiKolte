package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Retrive {

	public static void main(String[] args) {

		//Movie movie = new Movie();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager em = emf.createEntityManager();
		
		String jpql = " from Movie";
		Query query = em.createQuery(jpql);
		List<Movie> list = query.getResultList();
		
		for ( Movie m : list)
		{
			System.out.println(" Id is : "+ m.getId());
			System.out.println(" Name is : "+ m.getName());
			System.out.println(" Rating is : "+ m.getRating());

		}
		
	}

}
