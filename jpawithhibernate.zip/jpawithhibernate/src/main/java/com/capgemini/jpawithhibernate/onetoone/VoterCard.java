package com.capgemini.jpawithhibernate.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VoterCard")
public class VoterCard {
	@Id
	@Column
	private int vid;
	@Column
	private String address;
	@OneToOne(mappedBy= "VoterCard")
	private Person Person;
	
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public Person getPerson() {
		return Person;
	}
	public void setPerson(Person person) {
		Person = person;
	}
}
