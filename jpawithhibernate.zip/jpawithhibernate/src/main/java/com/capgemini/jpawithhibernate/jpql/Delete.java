package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		String jpql = " delete from Movie where id = 5";
		transaction.begin();
		Query query= em.createQuery(jpql);
		int result = query.executeUpdate();
		System.out.println(" Result is "+ result);
		transaction.commit();
		em.close();
	}

}
