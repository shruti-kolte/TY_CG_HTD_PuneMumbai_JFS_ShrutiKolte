package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Reference {
	public static void main(String[] args) {

		Movie movie = new Movie();

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Movie getData = entityManager.getReference(Movie.class, 311);
		System.out.println(getData.getName());
		//Movie data = entityManager.find(Movie.class, 1);
		System.out.println("Id is :"+getData.getId());
		System.out.println("Name is :"+getData.getName());
		System.out.println("Rating is :"+getData.getRating());
		System.out.println("-------------------------------------");
		
	}

}
